package br.integrado.Tech_academy4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechAcademy4Application {

	public static void main(String[] args) {
		SpringApplication.run(TechAcademy4Application.class, args);
	}

}
